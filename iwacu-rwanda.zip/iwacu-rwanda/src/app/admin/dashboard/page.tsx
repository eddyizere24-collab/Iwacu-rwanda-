"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  LogOut,
  Loader2,
  Users,
  Shield,
  RefreshCw,
  Pencil,
} from "lucide-react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";
import { LeaderEditForm } from "@/components/admin/LeaderEditForm";
import { maskPhone } from "@/lib/security/mask";
import type { LeaderPublic } from "@/types/leader";

interface AdminProfile {
  full_name: string;
  scope_code: string;
  is_super_admin: boolean;
}

interface LeaderRow extends LeaderPublic {
  phone_raw_masked: string | null;
}

export default function AdminDashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [profile, setProfile] = useState<AdminProfile | null>(null);
  const [leaders, setLeaders] = useState<LeaderRow[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [editing, setEditing] = useState<LeaderRow | null>(null);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    const supabase = createSupabaseBrowserClient();

    const {
      data: { user },
      error: authErr,
    } = await supabase.auth.getUser();

    if (authErr || !user) {
      router.replace("/admin/login");
      return;
    }

    // Fetch admin profile (RLS: self or super-admin)
    const { data: adminProfile, error: profileErr } = await supabase
      .from("admin_profiles")
      .select("full_name, scope_code, is_super_admin")
      .eq("user_id", user.id)
      .maybeSingle();

    if (profileErr || !adminProfile) {
      setError(
        "Ntabwo uri umuyobozi wanditswe. Vugana na super-admin."
      );
      setLoading(false);
      return;
    }

    setProfile(adminProfile);

    // Fetch leaders scoped by prefix (RLS enforces this too)
    let query = supabase
      .from("leaders")
      .select(
        `
        id,
        scope_code,
        first_name,
        last_name,
        role,
        email,
        photo_url,
        phone_number,
        valid_from,
        valid_to,
        version,
        boundaries!inner ( name_kiny, name_eng, level )
      `
      )
      .is("valid_to", null)
      .order("scope_code");

    if (!adminProfile.is_super_admin) {
      query = query.like("scope_code", `${adminProfile.scope_code}%`);
    }

    const { data: rows, error: leadersErr } = await query;

    if (leadersErr) {
      setError("Ntibyashobotse gushakisha abayobozi. Ongera ugerageze.");
      setLoading(false);
      return;
    }

    const mapped: LeaderRow[] = (rows ?? []).map(
      (row: Record<string, unknown>) => {
        const boundaries = row.boundaries as {
          name_kiny: string;
          name_eng: string | null;
          level: string;
        } | null;

        return {
          id: row.id as string,
          scope_code: row.scope_code as string,
          first_name: row.first_name as string,
          last_name: row.last_name as string,
          role: row.role as LeaderPublic["role"],
          email: (row.email as string) ?? null,
          photo_url: (row.photo_url as string) ?? null,
          valid_from: row.valid_from as string,
          valid_to: (row.valid_to as string) ?? null,
          version: row.version as number,
          boundary_name_kiny: boundaries?.name_kiny ?? "",
          boundary_name_eng: boundaries?.name_eng ?? null,
          level: boundaries?.level ?? "",
          phone_masked: maskPhone(row.phone_number as string | null),
          phone_raw_masked: maskPhone(row.phone_number as string | null),
        };
      }
    );

    setLeaders(mapped);
    setLoading(false);
  }, [router]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  async function handleLogout() {
    const supabase = createSupabaseBrowserClient();
    await supabase.auth.signOut();
    router.replace("/admin/login");
  }

  async function handleRefresh() {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  }

  function handleEditSuccess(updated: LeaderPublic) {
    setLeaders((prev) =>
      prev.map((l) =>
        l.id === updated.id
          ? {
              ...l,
              ...updated,
              phone_masked: updated.phone_masked,
              phone_raw_masked: updated.phone_masked,
            }
          : l
      )
    );
    setEditing(null);
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" aria-label="Turimo gushakisha" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 px-4">
        <p className="text-center text-destructive">{error}</p>
        <button
          type="button"
          onClick={handleLogout}
          className="inline-flex min-h-[44px] items-center gap-2 rounded-lg border border-border px-4 py-2 text-sm"
        >
          <LogOut className="h-4 w-4" /> Sohoka
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur">
        <div className="container mx-auto flex h-14 max-w-5xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Shield className="h-5 w-5 text-blue-600" aria-hidden />
            <div>
              <p className="text-sm font-semibold text-foreground">
                {profile?.full_name}
              </p>
              <p className="text-xs text-muted-foreground">
                Scope: {profile?.scope_code}
                {profile?.is_super_admin ? " · Super Admin" : ""}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRefresh}
              disabled={refreshing}
              aria-label="Ongera ushakishe"
              className="inline-flex h-11 w-11 items-center justify-center rounded-md border border-border hover:bg-muted"
            >
              <RefreshCw
                className={`h-4 w-4 ${refreshing ? "animate-spin" : ""}`}
              />
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="inline-flex min-h-[44px] items-center gap-2 rounded-md border border-border px-3 py-2 text-sm hover:bg-muted"
            >
              <LogOut className="h-4 w-4" />
              Sohoka
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto max-w-5xl px-4 py-8">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-green-600" aria-hidden />
            <h1 className="text-xl font-bold text-foreground">
              Abayobozi ({leaders.length})
            </h1>
          </div>
          <Link
            href="/"
            className="text-sm text-blue-600 hover:underline"
          >
            Reba urubuga rw’abaturage
          </Link>
        </div>

        {leaders.length === 0 ? (
          <p className="rounded-xl border border-border bg-card p-8 text-center text-muted-foreground">
            Nta bayobozi bahari kuri uyu scope.
          </p>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-border">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-border bg-muted/50">
                <tr>
                  <th className="px-4 py-3 font-medium">Amazina</th>
                  <th className="px-4 py-3 font-medium">Inshingano</th>
                  <th className="px-4 py-3 font-medium">Ahantu</th>
                  <th className="px-4 py-3 font-medium">Telefone</th>
                  <th className="px-4 py-3 font-medium">Version</th>
                  <th className="px-4 py-3 font-medium">
                    <span className="sr-only">Ibikorwa</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {leaders.map((leader) => (
                  <tr
                    key={leader.id}
                    className="border-b border-border last:border-0 hover:bg-muted/30"
                  >
                    <td className="px-4 py-3 font-medium text-foreground">
                      {leader.first_name} {leader.last_name}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      {leader.role}
                    </td>
                    <td className="px-4 py-3">
                      <span className="block text-foreground">
                        {leader.boundary_name_kiny}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {leader.scope_code}
                      </span>
                    </td>
                    <td className="px-4 py-3 font-mono text-xs">
                      {leader.phone_masked ?? "—"}
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">
                      v{leader.version}
                    </td>
                    <td className="px-4 py-3">
                      <button
                        type="button"
                        onClick={() => setEditing(leader)}
                        className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-md text-blue-600 hover:bg-blue-600/10"
                        aria-label={`Hindura ${leader.first_name}`}
                      >
                        <Pencil className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </main>

      {/* Edit modal */}
      {editing && (
        <LeaderEditForm
          leader={editing}
          onClose={() => setEditing(null)}
          onSuccess={handleEditSuccess}
        />
      )}
    </div>
  );
}
