/**
 * GET  /api/leaders?scope_code=RW-01-01-01-001[&reveal=true]
 * PATCH /api/leaders  (admin – optimistic locking)
 *
 * Phone numbers are masked by default (078***456).
 * Only when ?reveal=true AND the caller is an authenticated admin
 * with matching scope does the raw number get returned (still never
 * sent to the LLM).
 */

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import {
  createSupabaseServerClient,
  createSupabaseServiceClient,
} from "@/lib/supabase/server";
import { maskPhone } from "@/lib/security/mask";
import { createLocateError } from "@/lib/utils/errors";
import type { LeaderPublic } from "@/types/leader";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ---------------------------------------------------------------------------
// GET – public (masked) or admin (optional reveal)
// ---------------------------------------------------------------------------
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const scopeCode = searchParams.get("scope_code");
    const reveal = searchParams.get("reveal") === "true";

    if (!scopeCode || !/^RW(-[0-9A-Z]{2,})*$/.test(scopeCode)) {
      return NextResponse.json(createLocateError("NOT_FOUND"), {
        status: 400,
      });
    }

    const supabase = createSupabaseServiceClient();

    const { data, error } = await supabase
      .from("leaders")
      .select(
        `
        id,
        scope_code,
        first_name,
        last_name,
        role,
        email,
        photo_url,
        phone_number,
        valid_from,
        valid_to,
        version,
        boundaries!inner ( name_kiny, name_eng, level )
      `
      )
      .eq("scope_code", scopeCode)
      .is("valid_to", null);

    if (error) {
      console.error("[leaders] GET error:", error);
      return NextResponse.json(
        createLocateError("NETWORK_ERROR", { reason: error.message }),
        { status: 502 }
      );
    }

    if (!data || data.length === 0) {
      return NextResponse.json(createLocateError("LEADER_MISSING"), {
        status: 404,
      });
    }

    // Decide whether we are allowed to reveal the phone
    let canReveal = false;
    if (reveal) {
      const serverClient = await createSupabaseServerClient();
      const {
        data: { user },
      } = await serverClient.auth.getUser();

      if (user) {
        const { data: profile } = await supabase
          .from("admin_profiles")
          .select("scope_code, is_super_admin")
          .eq("user_id", user.id)
          .maybeSingle();

        if (
          profile &&
          (profile.is_super_admin ||
            scopeCode.startsWith(profile.scope_code))
        ) {
          canReveal = true;
        }
      }
    }

    const leaders: LeaderPublic[] = data.map(
      (row: Record<string, unknown>) => {
        const boundaries = row.boundaries as {
          name_kiny: string;
          name_eng: string | null;
          level: string;
        } | null;

        const phoneRaw = row.phone_number as string | null;

        return {
          id: row.id as string,
          scope_code: row.scope_code as string,
          first_name: row.first_name as string,
          last_name: row.last_name as string,
          role: row.role as LeaderPublic["role"],
          email: (row.email as string) ?? null,
          photo_url: (row.photo_url as string) ?? null,
          valid_from: row.valid_from as string,
          valid_to: (row.valid_to as string) ?? null,
          version: row.version as number,
          boundary_name_kiny: boundaries?.name_kiny ?? "",
          boundary_name_eng: boundaries?.name_eng ?? null,
          level: boundaries?.level ?? "",
          phone_masked: canReveal ? phoneRaw : maskPhone(phoneRaw),
        };
      }
    );

    const missingContact = leaders.every((l) => !l.phone_masked);
    if (missingContact) {
      return NextResponse.json(
        {
          status: "success",
          leaders,
          warning: "MISSING_LEADER_CONTACT",
        },
        { status: 200 }
      );
    }

    return NextResponse.json({ status: "success", leaders });
  } catch (err) {
    console.error("[leaders] GET unexpected:", err);
    return NextResponse.json(
      createLocateError("NETWORK_ERROR", {
        reason: err instanceof Error ? err.message : "unknown",
      }),
      { status: 502 }
    );
  }
}

// ---------------------------------------------------------------------------
// PATCH – admin only, optimistic locking → 409 on version mismatch
// ---------------------------------------------------------------------------
const PatchBodySchema = z.object({
  id: z.string().uuid(),
  version: z.number().int().positive(),
  first_name: z.string().min(1).optional(),
  last_name: z.string().min(1).optional(),
  role: z
    .enum([
      "Village Leader",
      "Cell Executive Secretary",
      "Sector Executive Secretary",
      "Mayor",
      "Vice Mayor",
      "District Executive Secretary",
      "Other",
    ])
    .optional(),
  phone_number: z
    .string()
    .regex(/^\+250[0-9]{9}$/)
    .optional()
    .nullable(),
  email: z.string().email().optional().nullable(),
  photo_url: z.string().url().optional().nullable(),
});

export async function PATCH(req: NextRequest) {
  try {
    const serverClient = await createSupabaseServerClient();
    const {
      data: { user },
    } = await serverClient.auth.getUser();

    if (!user) {
      return NextResponse.json(
        {
          status: "error",
          code: "UNAUTHORIZED",
          message_kiny: "Ongera winjire.",
        },
        { status: 401 }
      );
    }

    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        createLocateError("NETWORK_ERROR", { reason: "invalid_json" }),
        { status: 400 }
      );
    }

    const parsed = PatchBodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          status: "error",
          code: "VALIDATION_ERROR",
          details: parsed.error.flatten(),
        },
        { status: 400 }
      );
    }

    const payload = parsed.data;
    const supabase = createSupabaseServiceClient();

    const { data: current, error: fetchErr } = await supabase
      .from("leaders")
      .select("*")
      .eq("id", payload.id)
      .is("valid_to", null)
      .maybeSingle();

    if (fetchErr || !current) {
      return NextResponse.json(createLocateError("NOT_FOUND"), {
        status: 404,
      });
    }

    const { data: profile } = await supabase
      .from("admin_profiles")
      .select("scope_code, is_super_admin")
      .eq("user_id", user.id)
      .maybeSingle();

    if (
      !profile ||
      (!profile.is_super_admin &&
        !current.scope_code.startsWith(profile.scope_code))
    ) {
      return NextResponse.json(
        {
          status: "error",
          code: "FORBIDDEN",
          message_kiny: "Nta burenganzira ufite ku uyu mwanya.",
        },
        { status: 403 }
      );
    }

    // Optimistic locking
    if (current.version !== payload.version) {
      return NextResponse.json(
        {
          status: "error",
          code: "CONCURRENT_EDIT_CONFLICT",
          message_kiny:
            "Ubundi mukoresha ahinduye amakuru. Reba itandukaniro hanyuma wemeze.",
          message_eng:
            "Another user modified this record. Review the difference and confirm.",
          conflict: {
            server_version: current.version,
            your_version: payload.version,
            server_data: {
              first_name: current.first_name,
              last_name: current.last_name,
              role: current.role,
              phone_number: maskPhone(current.phone_number),
              email: current.email,
              photo_url: current.photo_url,
            },
            your_data: {
              first_name: payload.first_name,
              last_name: payload.last_name,
              role: payload.role,
              phone_number: payload.phone_number
                ? maskPhone(payload.phone_number)
                : undefined,
              email: payload.email,
              photo_url: payload.photo_url,
            },
          },
        },
        { status: 409 }
      );
    }

    const updates: Record<string, unknown> = {
      version: current.version + 1,
      updated_by: user.id,
    };
    if (payload.first_name !== undefined)
      updates.first_name = payload.first_name;
    if (payload.last_name !== undefined) updates.last_name = payload.last_name;
    if (payload.role !== undefined) updates.role = payload.role;
    if (payload.phone_number !== undefined)
      updates.phone_number = payload.phone_number;
    if (payload.email !== undefined) updates.email = payload.email;
    if (payload.photo_url !== undefined)
      updates.photo_url = payload.photo_url;

    const { data: updated, error: updateErr } = await supabase
      .from("leaders")
      .update(updates)
      .eq("id", payload.id)
      .eq("version", payload.version)
      .select()
      .maybeSingle();

    if (updateErr || !updated) {
      return NextResponse.json(
        {
          status: "error",
          code: "CONCURRENT_EDIT_CONFLICT",
          message_kiny:
            "Ubundi mukoresha ahinduye amakuru. Ongera ugerageze.",
        },
        { status: 409 }
      );
    }

    await supabase.from("audit_logs").insert({
      actor_id: user.id,
      action: "UPDATE",
      table_name: "leaders",
      record_id: payload.id,
      old_data: current,
      new_data: updated,
    });

    return NextResponse.json({
      status: "success",
      leader: {
        ...updated,
        phone_number: undefined,
        phone_masked: maskPhone(updated.phone_number),
      },
    });
  } catch (err) {
    console.error("[leaders] PATCH unexpected:", err);
    return NextResponse.json(
      createLocateError("NETWORK_ERROR", {
        reason: err instanceof Error ? err.message : "unknown",
      }),
      { status: 502 }
    );
  }
}
