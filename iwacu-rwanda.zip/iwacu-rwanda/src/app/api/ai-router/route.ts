/**
 * POST /api/ai-router
 *
 * Natural Language Router powered by Groq Function Calling.
 * ZERO PII is ever sent to Groq.
 * The model only extracts intent + parameters (scope_code, lat/lng…).
 * Backend then calls internal functions and returns structured data
 * that the frontend renders with fixed templates.
 */

import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import Groq from "groq-sdk";
import { createSupabaseServiceClient } from "@/lib/supabase/server";
import { maskPhone } from "@/lib/security/mask";
import { createLocateError } from "@/lib/utils/errors";
import type { AiRouterResponse } from "@/types/api";
import type { LeaderPublic } from "@/types/leader";
import type { LocateResponse } from "@/types/location";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const BodySchema = z.object({
  query: z.string().min(1).max(500),
  context_scope_code: z
    .string()
    .regex(/^RW(-[0-9A-Z]{2,})*$/)
    .optional(),
});

const SYSTEM_PROMPT = `You are the intent router for IWACU RWANDA, a civic platform that helps citizens find their administrative location and local leaders in Rwanda.

RULES (STRICT):
1. You NEVER receive or request personal data (names, phone numbers, emails, GPS coordinates of citizens).
2. You ONLY extract intent and parameters. You do NOT answer with leader details yourself.
3. Supported intents:
   - locate_by_text: user asks "Ndi he?", "Where am I?", "Find my village" → call get_location_hint
   - get_leader: user asks for a leader of a known place → call get_leader_by_scope
   - unknown: anything else
4. scope_code format is hierarchical: RW-01 (district), RW-01-01 (sector), RW-01-01-01 (cell), RW-01-01-01-001 (village).
5. Respond ONLY via the provided functions. Never invent data.

Current date context: 2026. Language of user may be Kinyarwanda or English.`;

const TOOLS: Groq.Chat.ChatCompletionTool[] = [
  {
    type: "function",
    function: {
      name: "get_leader_by_scope",
      description:
        "Retrieve active leaders for a given administrative scope_code. Use when the user asks about a leader of a specific place.",
      parameters: {
        type: "object",
        properties: {
          scope_code: {
            type: "string",
            description:
              "Hierarchical code, e.g. RW-01 for Gasabo district, RW-01-01-01-001 for a village.",
          },
        },
        required: ["scope_code"],
      },
    },
  },
  {
    type: "function",
    function: {
      name: "get_location_hint",
      description:
        "User is asking where they are or wants to start a location lookup. Returns a message telling the frontend to trigger GPS or manual search. No coordinates are passed.",
      parameters: {
        type: "object",
        properties: {
          message_kiny: {
            type: "string",
            description: "Short formal Kinyarwanda instruction for the user.",
          },
        },
        required: ["message_kiny"],
      },
    },
  },
];

export async function POST(
  req: NextRequest
): Promise<NextResponse<AiRouterResponse>> {
  try {
    let body: unknown;
    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        {
          status: "error",
          code: "INVALID_JSON",
          message_kiny: "Ikibazo cy’ikosa. Ongera ugerageze.",
        },
        { status: 400 }
      );
    }

    const parsed = BodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        {
          status: "error",
          code: "VALIDATION_ERROR",
          message_kiny: "Ikibazo cy’ikosa. Ongera ugerageze.",
        },
        { status: 400 }
      );
    }

    const { query, context_scope_code } = parsed.data;

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) {
      console.error("[ai-router] GROQ_API_KEY missing");
      return NextResponse.json(
        {
          status: "error",
          code: "NETWORK_ERROR",
          message_kiny: "Serivisi ya AI ntabwo ihari. Gerageza nyuma.",
        },
        { status: 502 }
      );
    }

    const groq = new Groq({ apiKey });

    // Build messages — ZERO PII
    const messages: Groq.Chat.ChatCompletionMessageParam[] = [
      { role: "system", content: SYSTEM_PROMPT },
      {
        role: "user",
        content: context_scope_code
          ? `[context_scope_code=${context_scope_code}] ${query}`
          : query,
      },
    ];

    const completion = await groq.chat.completions.create({
      model: "llama-3.3-70b-versatile",
      messages,
      tools: TOOLS,
      tool_choice: "auto",
      temperature: 0.1,
      max_tokens: 300,
    });

    const choice = completion.choices[0];
    const toolCalls = choice?.message?.tool_calls;

    if (!toolCalls || toolCalls.length === 0) {
      return NextResponse.json({
        status: "success",
        intent: "unknown",
        data: null,
        message_kiny:
          "Sinumvise neza. Gerageza kuvuga: \"Ndi he?\" cyangwa \"Umuyobozi w'umudugudu wanjye\".",
      });
    }

    const call = toolCalls[0];
    const fnName = call.function.name;
    let args: Record<string, unknown> = {};
    try {
      args = JSON.parse(call.function.arguments || "{}");
    } catch {
      args = {};
    }

    // ------------------------------------------------------------------
    // Execute internal backend functions (never return raw AI text)
    // ------------------------------------------------------------------
    if (fnName === "get_leader_by_scope") {
      const scopeCode = String(args.scope_code || context_scope_code || "");
      if (!scopeCode || !/^RW(-[0-9A-Z]{2,})*$/.test(scopeCode)) {
        return NextResponse.json({
          status: "success",
          intent: "get_leader",
          data: null,
          message_kiny:
            "Ntabwo nashoboye kumenya aho ushaka. Gerageza gushyiraho izina ry’umurenge cyangwa akagari.",
        });
      }

      const leaders = await fetchLeadersByScope(scopeCode);
      if (leaders.length === 0) {
        return NextResponse.json({
          status: "success",
          intent: "get_leader",
          data: { leaders: [] },
          message_kiny: "Nta muyobozi uhari kuri uyu mwanya.",
        });
      }

      return NextResponse.json({
        status: "success",
        intent: "get_leader",
        data: { leaders },
        message_kiny: `Dore abayobozi ba ${scopeCode}:`,
      });
    }

    if (fnName === "get_location_hint") {
      const msg =
        typeof args.message_kiny === "string"
          ? args.message_kiny
          : "Kanda ku butumwa bwo gukoresha GPS cyangwa shakisha manuelle.";
      return NextResponse.json({
        status: "success",
        intent: "locate",
        data: null,
        message_kiny: msg,
      });
    }

    return NextResponse.json({
      status: "success",
      intent: "unknown",
      data: null,
      message_kiny:
        "Sinumvise neza. Gerageza kuvuga: \"Ndi he?\" cyangwa \"Umuyobozi w'akarere\".",
    });
  } catch (err) {
    console.error("[ai-router] Unexpected:", err);
    return NextResponse.json(
      {
        status: "error",
        code: "NETWORK_ERROR",
        message_kiny: "Ikibazo cy’urukurikirane. Gerageza nanone.",
      },
      { status: 502 }
    );
  }
}

// ---------------------------------------------------------------------------
// Internal helper — phones always masked
// ---------------------------------------------------------------------------
async function fetchLeadersByScope(
  scopeCode: string
): Promise<LeaderPublic[]> {
  const supabase = createSupabaseServiceClient();

  const { data, error } = await supabase
    .from("leaders")
    .select(
      `
      id,
      scope_code,
      first_name,
      last_name,
      role,
      email,
      photo_url,
      phone_number,
      valid_from,
      valid_to,
      version,
      boundaries!inner ( name_kiny, name_eng, level )
    `
    )
    .eq("scope_code", scopeCode)
    .is("valid_to", null);

  if (error || !data) return [];

  return data.map((row: Record<string, unknown>) => {
    const boundaries = row.boundaries as {
      name_kiny: string;
      name_eng: string | null;
      level: string;
    } | null;

    return {
      id: row.id as string,
      scope_code: row.scope_code as string,
      first_name: row.first_name as string,
      last_name: row.last_name as string,
      role: row.role as LeaderPublic["role"],
      email: (row.email as string) ?? null,
      photo_url: (row.photo_url as string) ?? null,
      valid_from: row.valid_from as string,
      valid_to: (row.valid_to as string) ?? null,
      version: row.version as number,
      boundary_name_kiny: boundaries?.name_kiny ?? "",
      boundary_name_eng: boundaries?.name_eng ?? null,
      level: boundaries?.level ?? "",
      phone_masked: maskPhone(row.phone_number as string | null),
    };
  });
}
