/**
 * Admin CRUD for leaders.
 * All writes require `version` and enforce optimistic locking → 409 on conflict.
 * RLS + scope_code prefix authorization enforced at DB + application layer.
 */
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  return NextResponse.json({ status: "error", code: "NOT_IMPLEMENTED" }, { status: 501 });
}

export async function POST(req: NextRequest) {
  return NextResponse.json({ status: "error", code: "NOT_IMPLEMENTED" }, { status: 501 });
}

export async function PATCH(req: NextRequest) {
  return NextResponse.json({ status: "error", code: "NOT_IMPLEMENTED" }, { status: 501 });
}
