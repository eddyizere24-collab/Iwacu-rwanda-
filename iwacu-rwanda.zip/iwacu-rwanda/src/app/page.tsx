"use client";

import { useLocation } from "@/hooks/useLocation";
import { LocationButton } from "@/components/LocationButton";
import { ErrorDisplay } from "@/components/ErrorDisplay";
import { LeaderCard } from "@/components/LeaderCard";
import { MapPin, WifiOff, ShieldCheck } from "lucide-react";

export default function HomePage() {
  const {
    status,
    data,
    errorCode,
    errorMessageKiny,
    errorMessageEng,
    isOffline,
    locate,
    reset,
  } = useLocation();

  return (
    <div className="container mx-auto max-w-3xl px-4 py-10 sm:py-16">
      {/* Hero */}
      <section className="mb-12 text-center" aria-labelledby="hero-title">
        <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600/10 text-blue-600">
          <MapPin className="h-8 w-8" aria-hidden />
        </div>

        <h1
          id="hero-title"
          className="mb-3 text-3xl font-bold tracking-tight text-foreground sm:text-4xl"
        >
          Murakaza neza kuri{" "}
          <span className="text-blue-600">IWACU RWANDA</span>
        </h1>

        <p className="mx-auto mb-8 max-w-lg text-base text-muted-foreground sm:text-lg">
          Menya aho uri n’abayobozi b’umudugudu, akagari, umurenge n’akarere
          mu buryo bwizewe kandi bwihariye.
        </p>

        {/* Primary CTA */}
        {(status === "idle" ||
          status === "requesting_gps" ||
          status === "locating") && (
          <div className="flex flex-col items-center gap-4">
            <LocationButton status={status} onClick={locate} />
            <p className="text-xs text-muted-foreground">
              Tuzakoresha GPS ya telefone yawe. Nta makuru yihariye dufata.
            </p>
          </div>
        )}
      </section>

      {/* Offline banner */}
      {isOffline && status === "success" && (
        <div
          role="status"
          className="mb-6 flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-800 dark:text-amber-200"
        >
          <WifiOff className="h-4 w-4 shrink-0" aria-hidden />
          <span>
            Uri offline. Dukoresha amakuru yabitswe (Gasabo gusa).
          </span>
        </div>
      )}

      {/* Error state */}
      {status === "error" && errorCode && errorMessageKiny && (
        <section className="mb-10" aria-label="Ikibazo">
          <ErrorDisplay
            code={errorCode}
            messageKiny={errorMessageKiny}
            messageEng={errorMessageEng}
            onRetry={locate}
          />
        </section>
      )}

      {/* Success: location + leaders */}
      {status === "success" && data && (
        <section className="space-y-8" aria-label="Ibisubizo">
          {/* Confidence summary */}
          <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
            <div className="mb-4 flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-green-600" aria-hidden />
              <h2 className="text-lg font-semibold text-foreground">
                Aho uri
              </h2>
            </div>

            {data.matches.length > 0 && (
              <ul className="space-y-2">
                {data.matches.map((m) => (
                  <li
                    key={m.scope_code}
                    className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3"
                  >
                    <div>
                      <p className="font-medium text-foreground">
                        {m.name_kiny}
                      </p>
                      <p className="text-xs text-muted-foreground capitalize">
                        {m.level}
                        {m.name_eng ? ` · ${m.name_eng}` : ""}
                      </p>
                    </div>
                    <span
                      className={`
                        inline-flex min-w-[3.5rem] items-center justify-center rounded-full px-2.5 py-1 text-sm font-semibold
                        ${
                          m.confidence >= 60
                            ? "bg-green-600/15 text-green-700 dark:text-green-400"
                            : m.confidence >= 30
                              ? "bg-amber-500/15 text-amber-700 dark:text-amber-400"
                              : "bg-muted text-muted-foreground"
                        }
                      `}
                    >
                      {m.confidence.toFixed(0)}%
                    </span>
                  </li>
                ))}
              </ul>
            )}

            {/* Hierarchy badges */}
            {data.hierarchy && (
              <div className="mt-4 flex flex-wrap gap-2">
                {data.hierarchy.district && (
                  <HierarchyBadge
                    label="Akarere"
                    name={data.hierarchy.district.name_kiny}
                    confidence={data.hierarchy.district.confidence}
                  />
                )}
                {data.hierarchy.sector && (
                  <HierarchyBadge
                    label="Umurenge"
                    name={data.hierarchy.sector.name_kiny}
                    confidence={data.hierarchy.sector.confidence}
                  />
                )}
                {data.hierarchy.cell && (
                  <HierarchyBadge
                    label="Akagari"
                    name={data.hierarchy.cell.name_kiny}
                    confidence={data.hierarchy.cell.confidence}
                  />
                )}
                {data.hierarchy.village && (
                  <HierarchyBadge
                    label="Umudugudu"
                    name={data.hierarchy.village.name_kiny}
                    confidence={data.hierarchy.village.confidence}
                  />
                )}
              </div>
            )}
          </div>

          {/* Leaders */}
          {data.leaders.length > 0 ? (
            <div>
              <h2 className="mb-4 text-lg font-semibold text-foreground">
                Abayobozi bawe
              </h2>
              <div className="grid gap-4 sm:grid-cols-1">
                {data.leaders.map((leader) => (
                  <LeaderCard key={leader.id} leader={leader} />
                ))}
              </div>
            </div>
          ) : (
            !isOffline && (
              <p className="text-center text-sm text-muted-foreground">
                Nta bayobozi babonetse kuri uyu mwanya.
              </p>
            )
          )}

          {/* Reset */}
          <div className="flex justify-center pt-4">
            <button
              type="button"
              onClick={reset}
              className="inline-flex min-h-[44px] items-center justify-center rounded-lg border border-border bg-background px-5 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
            >
              Shakisha ahantu handi
            </button>
          </div>
        </section>
      )}

      {/* Loading skeleton (slow network) */}
      {status === "locating" && (
        <div className="mt-10 space-y-4" aria-busy="true" aria-label="Turimo gushakisha">
          <div className="skeleton h-24 w-full rounded-xl" />
          <div className="skeleton h-32 w-full rounded-xl" />
          <div className="skeleton h-32 w-full rounded-xl" />
        </div>
      )}
    </div>
  );
}

function HierarchyBadge({
  label,
  name,
  confidence,
}: {
  label: string;
  name: string;
  confidence: number;
}) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background px-3 py-1 text-xs">
      <span className="font-medium text-muted-foreground">{label}:</span>
      <span className="font-semibold text-foreground">{name}</span>
      <span className="text-muted-foreground">({confidence.toFixed(0)}%)</span>
    </span>
  );
}
